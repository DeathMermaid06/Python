from setuptools import setup

setup(
    name="Paquete-Pistasoli-Entrega2",
    version="1.2",
    description="Paquete modelado de clientes",
    author="Mariela Pistasoli",
    packages=["paquete"],
)